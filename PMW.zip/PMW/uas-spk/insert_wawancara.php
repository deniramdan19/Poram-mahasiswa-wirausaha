<?php
include("dp.php");
if (isset($_POST['Upload'])) {


    // $a = $_POST["no"];
    $b = $_POST["nim"];
    $c = $_POST["nama"];
    $d = $_POST["prodi"];
    $e = $_POST["ide_usaha"];
    $f = $_POST["tanggal"];
    $g = $_POST["waktu"];


    mysqli_query($koneksi, "insert into wawancara values (null, '$b', '$c', '$d', '$e', '$f', '$g')");
    header("Location: wawancara.php");
}