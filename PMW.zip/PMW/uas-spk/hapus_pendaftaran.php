<?php
include('dp.php');
$a = $_GET['No'];

mysqli_query($koneksi, "delete from pendaftaran where no= '$a'");
header("Location:pendaftaran.php")
    ?>