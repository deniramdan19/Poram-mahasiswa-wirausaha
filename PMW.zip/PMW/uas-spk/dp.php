<?php
$serverSQL = "localhost";
$user = "root";
$pass = "";


$koneksi = mysqli_connect($serverSQL, $user, $pass, "pmw");


function funQuery($query)
{
    global $koneksi;

    $result = mysqli_query($koneksi, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function funUbah($data)
{
    global $koneksi;
    // ambil data dari tiap elemen dalam form
    $id = ($data["no"]);
    $nim = htmlspecialchars($data["nim"]);
    $nama = htmlspecialchars($data["nama"]);
    $prodi = htmlspecialchars($data["prodi"]);
    $semester = htmlspecialchars($data["semester"]);
    $ideusaha = htmlspecialchars($data["ideusaha"]);


    // query update data
    $query = "UPDATE pendaftaran SET
              nim = '$nim',
              nama = '$nama', 
              prodi = '$prodi',
              semester = '$semester',
              ideusaha = '$ideusaha'    
              WHERE no = $id
              ";

    mysqli_query($koneksi, $query);

    return mysqli_affected_rows($koneksi);
}


function funUbah1($data)
{
    global $koneksi;
    // ambil data dari tiap elemen dalam form
    $id = ($data["no"]);
    $nim = htmlspecialchars($data["nim"]);
    $nama = htmlspecialchars($data["nama"]);
    $prodi = htmlspecialchars($data["prodi"]);
    $ideusaha = htmlspecialchars($data["ideusaha"]);
    $tanggal = htmlspecialchars($data["tanggal"]);
    $waktu = htmlspecialchars($data["waktu"]);


    // query update data
    $query = "UPDATE wawancara SET
              nim = '$nim', 
              nama = '$nama',
              prodi = '$prodi',
              ideusha = '$ideusaha',
              tanggal = '$tanggal',
              waktu = '$waktu'
              WHERE no = $id
              ";

    mysqli_query($koneksi, $query);

    return mysqli_affected_rows($koneksi);
}