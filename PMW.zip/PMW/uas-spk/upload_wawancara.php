<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/css/Stylee.css">
    <link rel="stylesheet" href="Aset/Support/fontawesome/css/all.css">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <title>upload</title>
</head>

<body>
    <div class="upload">
        <h4><i><img src="Aset/img/pmw.png" alt="logo"></i> Program mahasiswa wirausaha</h4>
        <form action="insert_wawancara.php" method="post">
            <!-- <input type="hidden" name="No"> -->
            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">nim : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nim" placeholder="">
                </div>
            </div>

            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">nama : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" placeholder="">
                </div>
            </div>

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">prodi : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="prodi" placeholder="">
                </div>
            </div>

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">ide usaha : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="ide_usaha" placeholder="">
                </div>
            </div>

            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">tanggal : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="tanggal" placeholder="">
                </div>
            </div>
            <br><br><br>

            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">waktu : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="waktu" placeholder="">
                </div>
            </div>
            <br><br><br>

            <input type="submit" class="btn btn-primary" name="Upload" value="Upload">
        </form>
    </div>

</body>

</html>