1. ku urang file "utama.php" diganti jadi "index.php" supaya tiap masuk localhost bakal langsung masuk kadinya / default page.
2. di file "upload_x.php" ku urg comment/disable input "No" karena ga butuh. soalna mnh dah pake auto_increment di databasena.

<form action="insert_proker.php" method="post">
            <!-- <input type="hidden" name="No"> --> <--- disini
            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">Program Kerja : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="ProgramKerja" placeholder="">
                </div>
            </div>

3. di file "insert_x.php" ku urg comment/disable oge nu nyimpen nilai No, terus ganti '' jadi null pas INSERT INTO na karena auto_increment.

   // $a = $_POST["No"]; <---- disini
    $b = $_POST["ProgramKerja"];
    $c = $_POST["WaktuPelaksanaan"];
    $d = $_POST["DeskripsiKegiatan"];
    $e = $\_POST["Status"];

   mysqli_query($koneksi, "insert into proker values (null, '$b', '$c', '$d', '$e')"); <--- disini
   header("Location: proker.php");

4. di file "update_x.php" sebenerna gada yang salah, salahna di fungsi di file "dp.php" bagian funUbah :

ieu sebelum ku urg ganti :
$query = "UPDATE proker SET
              ProgramKerja = '$proker',
WaktuPelaksanaan = '$waktu',
              DeskripsiKegiatan = '$deskrip',
Status = '$status', <----disini
WHERE No = $id
";

ieu sanggeus urg ganti :
$query = "UPDATE proker SET
              ProgramKerja = '$proker',
WaktuPelaksanaan = '$waktu',
              DeskripsiKegiatan = '$deskrip',
Status = '$status' <----- disini
WHERE No = $id
";

perbedaanna penggunaan koma sebelum klausa WHERE.
