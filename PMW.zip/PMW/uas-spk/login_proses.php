<?php
include('dp.php');
session_start();

if (isset($_POST['login'])) {

    $a = $_POST['user'];
    $b = $_POST['pass'];

    $c = "select * from login where username = '$a' and password = '$b'";
    $hasil = mysqli_query($koneksi, $c);
    $e = mysqli_num_rows($hasil);
    $f = mySQli_fetch_array($hasil);

    if ($e == 1) {
        $_SESSION['user-login'] = $a;
        // $_SESSION['level'] = $f['role'];
        header('location: dasboard.php');
    } else {
        // $_SESSION['gagal'] = "maaf kamu tidak bisa login karna kamu yahudi";
        // echo $_SESSION['gagal'];
        echo "
        <script>
            alert('maaf kamu tidak bisa login karna kamu yahudi');
            document.location.href = 'login.php';
        </script>
        ";
    }
}