<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <link rel="stylesheet" href="Aset/css/Stylee.css">
    <title>PMW</title>
</head>

<body>
    <section class="vh-100">
        <div class="container-fluid">
            <div class="row vh-100">
                <div class="col-sm-5 text-black">

                    <div class="font d-flex align-items-center h-custom-2 px-5 ms-xl-4 mt-5 pt-5 pt-xl-0 mt-xl-n5">

                        <form style="width: 23rem;" action="login_proses.php" method="post">
                            <h2 class="fw-normal mb-1 fw-bold" style="letter-spacing: 1px;">welcome :)</h2>
                            <h3 class="fw-normal mb-0 pb-5" style="letter-spacing: 1px;">LogIn!</h3>

                            <div class="borderlogin justify-content-center">


                                <div class="form-outline mb-2 mt-4">
                                    <label class="form-label" for="form2Example18">Username</label>
                                    <input type="text" name="user" id="form2Example18" />
                                </div>

                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form2Example28">Password</label>
                                    <input type="password" name="pass" id="form2Example28" />
                                </div>

                                <div class=" login pt-1 mb-4 text-center">
                                    <input type="submit" name="login" value="Login">
                                    <!-- <button class="btn btn-info btn-lg btn-block" type="button">Login</button> -->
                                </div>

                                <p class="small mb-5 pb-lg-2"><a class="text-muted" href="#!">Forgot password?</a></p>
                                <p class="mb-4">Don't have an account? <a href="register.php" class="link-info">Register
                                        here</a>
                                </p>
                            </div>

                        </form>

                    </div>

                </div>
                <div class="radius col-md-7 px-0 d-none d-sm-block" style="background-color: #6495ED"
                    class="w-100 vh-100">
                    <img src="Aset/img/pmw.png" alt="Login image" style="object-fit: cover; object-position: left;">
                    <h2>Program Mahasiswa Wirausaha</h2>
                </div>
            </div>
        </div>
    </section>
</body>

</html>

<?php
include('dp.php');
session_start();

if (isset($_POST['login'])) {

    $a = $_POST['user'];
    $b = $_POST['pass'];

    $c = "select * from user where user = '$a' and password = '$b'";
    $hasil = mysqli_query($koneksi, $c);
    $e = mysqli_num_rows($hasil);
    $f = mySQli_fetch_array($hasil);

    if ($e == 1) {
        $_SESSION['user-login'] = $a;
        $_SESSION['level'] = $f['role'];
        header('location: dasboard.php');
    } else {

        echo "
        <script>
            alert('maaf kamu tidak bisa login dikarnakan user atau password salah');
            document.location.href = 'login.php';
        </script>
        ";
    }
}