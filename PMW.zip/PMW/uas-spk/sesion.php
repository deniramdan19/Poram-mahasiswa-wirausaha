<?php

// session_start();
if (!isset($_SESSION['user-login'])) {
    header('Location: utama.php');
    exit();
}
