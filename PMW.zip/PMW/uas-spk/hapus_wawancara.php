<?php
include('dp.php');
$a = $_GET['No'];

mysqli_query($koneksi, "delete from wawancara where no= '$a'");
header("Location:wawancara.php")
    ?>