<?php
include("dp.php");
if (isset($_POST['Upload'])) {


    // $a = $_POST["no"];
    $b = $_POST["nim"];
    $c = $_POST["nama"];
    $d = $_POST["prodi"];
    $e = $_POST["semester"];
    $f = $_POST["ideusaha"];



    mysqli_query(
        $koneksi,
        "INSERT INTO pendaftaran (nim, nama, prodi, semester, ideusaha)
         VALUES ('$b', '$c', '$d', '$e', '$f')"
    );
    header("Location: pendaftaran.php");
}
?>