<?php
include('dp.php');
// include('cari');
$id = $_GET['No'];
$row = funQuery("SELECT * FROM pendaftaran WHERE No = $id")[0];

if (isset($_POST['Update'])) {
    // cek apakah data berhasil ditambahkan?
    if (funUbah($_POST) > 0) {
        echo "
        <script>
            alert('Data berhasil diubah!');
            document.location.href = 'pendaftaran.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Data gagal diubah!');
            document.location.href = 'update_pendaftaran.php';
        </script>
        ";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/css/Stylee.css">
    <link rel="stylesheet" href="Aset/Support/fontawesome/css/all.css">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <title>update</title>
</head>

<body>
    <div class="upload">
        <h4><i><img src="Aset/img/pmw.png" alt="logo"></i> Programkerja Mahasiswa Wirausaha</h4>
        <br><br>
        <h3>Update Pendaftaran</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="no" value="<?php echo $row['no'] ?>">
            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">nim : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nim" value="<?php echo $row['nim'] ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">nama : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" placeholder=""
                        value="<?php echo $row['nama'] ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">prodi : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="prodi" placeholder=""
                        value="<?php echo $row['prodi'] ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">semester : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="semester" placeholder=""
                        value="<?php echo $row['semester'] ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">ide usaha : </label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="ideusaha" placeholder=""
                        value="<?php echo $row['ideusaha'] ?>">
                </div>
            </div>

            <br><br><br>

            <input type="submit" class="btn btn-primary" name="Update">
        </form>
    </div>

</body>

</html>