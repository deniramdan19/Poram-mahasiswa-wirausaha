<?php
session_start();
include('sesion.php');
include('dp.php');

?>
<?php
$hasil = mysqli_query($koneksi, "select * from pendaftaran");

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/css/Stylee.css">
    <link rel="stylesheet" href="Aset/Support/fontawesome/css/all.css">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <title>Proker</title>
</head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3><i><img src="Aset/img/pmw.png" alt="logo"></i> PMW</h3>
                <hr>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="dasboard.php"><i class="fa-solid fa-house"></i> Home</a>
                </li>

                <li>
                    <a href="pendaftaran.php"><i class="fa-solid fa-laptop-code"></i> Pendaftaran</a>
                </li>

                <li>
                    <a href="berkas.php"><i class="fa-solid fa-clock-rotate-left"></i> berkas</a>
                </li>

                <!-- <li>
                    <a href="#"><i class="fa-solid fa-image"></i> gallery</a>
                </li> -->
                <li>
                    <a href="wawancara.php"><i class="fa-solid fa-clipboard"></i> wawancara</a>
                </li>

                <li>
                    <a href="penerima.php"><i class="fa-solid fa-clipboard"></i> penerima</a>
                </li>
            </ul>

            <div class="input">
                <a href="logout.php" class="btn btn-info">Logout</a>

            </div>

        </nav>

        <!-- Page Content  -->
        <section class="content-section">
            <div class="navbar1">
                <h1><i><img src="Aset/img/pmw.png" alt="logo"></i> Program Mahasiswa Wirausaha</h1>

                <br>
                <hr>

            </div>

            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>PENDAFTARAN</h2>
                        <div class="insert">
                            <a class="btn btn-primary" href="upload_pendaftaran.php">insert <i
                                    class="fa-solid fa-plus"></i></a>
                        </div>
                        <table border="1" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">no</th>
                                    <th scope="col">nim</th>
                                    <th scope="col">nama</th>
                                    <th scope="col">prodi</th>
                                    <th scope="col">semester</th>
                                    <th scope="col">ide judul</th>
                                    <div class="action">
                                        <th scope="col">Actions</th>
                                    </div>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($hasil as $cetak): ?>
                                    <tr>
                                        <td>
                                            <?php echo $i; ?>
                                        </td>
                                        <td>
                                            <?php echo $cetak["nim"]; ?>
                                        </td>
                                        <td>
                                            <?php echo $cetak["nama"]; ?>
                                        </td>
                                        <td>
                                            <?php echo $cetak["prodi"]; ?>
                                        </td>
                                        <td>
                                            <?php echo $cetak["semester"]; ?>
                                        </td>
                                        <td>
                                            <?php echo $cetak["ideusaha"]; ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-success"
                                                href="update_pendaftaran.php?No=<?php echo $cetak['no']; ?>"><i
                                                    class="fas fa-edit"></i> </a>
                                            <a class="btn btn-danger"
                                                href="hapus_pendaftaran.php?No=<?php echo $cetak['no']; ?>"><i
                                                    class="far fa-trash-alt"></i> </a>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>


                            </tbody>
                        </table>

                        <input type="submit" class="btn btn-primary" name="Upload" value="Upload">

                        <br><br>
                        <hr><br><br>


                    </div>
                </div>
            </div>
    </div>
    </section>

</body>

</html>