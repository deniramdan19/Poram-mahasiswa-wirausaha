<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/css/berkas.css">
    <link rel="stylesheet" href="Aset/Support/fontawesome/css/all.css">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <title>History</title>
</head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3><i><img src="Aset/img/pmw.png" alt="logo"></i> PMW</h3>
                <hr>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="dasboard.php"><i class="fa-solid fa-house"></i> Home</a>
                </li>

                <li>
                    <a href="pendaftaran.php"><i class="fa-solid fa-laptop-code"></i> Pendaftaran</a>
                </li>

                <li>
                    <a href="berkas.php"><i class="fa-solid fa-clock-rotate-left"></i> berkas</a>
                </li>

                <!-- <li>
                    <a href="#"><i class="fa-solid fa-image"></i> gallery</a>
                </li> -->
                <li>
                    <a href="wawancara.php"><i class="fa-solid fa-clipboard"></i> wawancara</a>
                </li>

                <li>
                    <a href="penerima.php"><i class="fa-solid fa-clipboard"></i> penerima</a>
                </li>
            </ul>

            <div class="input">
                <!-- <input class="btn btn-info" type="button" nama="tombol1" value="LogOut"> -->

                <a href="logout.php" class="btn btn-info">Logout</a>
            </div>
        </nav>>

        <!-- Page Content  -->
        <section class="content-section">
            <div class="navbar1">

                <h1><i><img src="Aset/img/pmw.png" alt="logo"></i> Program Mahasiswa Wirausaha</h1>

                <br>
                <hr>

            </div>

            <div class="content3">
                <div class="row">
                    <h2>Berkas program mahasiswa wirausaha</h2>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="float">
                                    <img src="Aset/img/pmw.png" alt="history">
                                </div>
                                <h5 class="card-title">PROGRAM MAHASISWA USAHA</h5>
                                <p class="card-text">2024 - 2025</p>
                                <a href="berkas2024.php" class="btn btn-primary">Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <br><br><br><br><br>
                        <div class="card">
                            <div class="card-body">
                                <div class="float">
                                    <img src="Aset/img/pmw.png" alt="history">
                                </div>
                                <h5 class="card-title">PROGRAM MAHASISWA USAHA</h5>
                                <p class="card-text">2025 -2026.</p>
                                <a href="berkas2025.php" class="btn btn-primary">Lihat Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</body>

</html>