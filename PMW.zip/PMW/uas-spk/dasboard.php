<?php
session_start();
include('sesion.php');


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Aset/css/Stylee.css">
    <link rel="stylesheet" href="Aset/Support/fontawesome/css/all.css">
    <link rel="stylesheet" href="Aset/Support/boostrep/css/bootstrap.min.css">
    <title>Dasboard</title>
</head>

<body>



    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3><i><img src="Aset/img/pmw.png" alt="logo"></i> PMW</h3>
                <hr>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="dasboard.php"><i class="fa-solid fa-house"></i> Home</a>
                </li>

                <li>
                    <a href="pendaftaran.php"><i class="fa-solid fa-laptop-code"></i> Pendaftaran</a>
                </li>

                <li>
                    <a href="berkas.php"><i class="fa-solid fa-clock-rotate-left"></i> berkas</a>
                </li>

                <!-- <li>
                    <a href="#"><i class="fa-solid fa-image"></i> gallery</a>
                </li> -->
                <li>
                    <a href="laporan.php"><i class="fa-solid fa-clipboard"></i> wawancara</a>
                </li>

                <li>
                    <a href="laporan.php"><i class="fa-solid fa-clipboard"></i> penerima</a>
                </li>
            </ul>

            <div class="input">
                <!-- <input class="btn btn-info" type="button" nama="tombol1" value="LogOut"> -->

                <a href="logout.php" class="btn btn-info">Logout</a>
            </div>
        </nav>

        <!-- Page Content  -->
        <section class="content-section">
            <div class="navbar1">

                <h1><i><img src="Aset/img/pmw.png" alt="logo"></i> Program Mahasiswa Wirausaha</h1>

                <br>
                <hr>

            </div>

            <div class="content2">

                <div class="vs">
                    <h2>Visi</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore
                        et
                        dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquip
                        ex
                        ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                        dolore
                        eu
                        fugiat
                        nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                        deserunt
                        mollit
                        anim id est laborum.</p>



                    <h2>Misi</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore
                        et
                        dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquip
                        ex
                        ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
                        dolore
                        eu
                        fugiat
                        nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia
                        deserunt
                        mollit
                        anim id est laborum.</p>
                </div>
            </div>
    </div>
    </section>

</body>

</html>